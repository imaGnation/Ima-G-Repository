﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ima_G_Nation_Site.Controllers
{
    public class ContentController : Controller
    {
        //
        // GET: /Content/

        public ActionResult Upload()
        {
            return View();
        }

    }
}
