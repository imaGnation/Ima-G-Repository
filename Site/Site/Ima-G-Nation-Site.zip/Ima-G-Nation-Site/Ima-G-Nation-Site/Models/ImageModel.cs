﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ima_G_Nation_Site.Models
{
    public class ImageModel
    {
    }
}